# CHANGELOG.md

## 1.0.4 (Dec 16, 2018)

##### Update PDF file
* /Sienna.pdf

## 1.0.3 (Nov 19, 2018)

##### Update PDF file
* /Sienna.pdf

## 1.0.2 (Nov 8, 2018)

##### Fix typo
* /index.html

## 1.0.1 (Nov 7, 2018)

##### Adjust testimonial image padding
* /src/scss/layout/_testimonial.scss

## 1.0.0 (Oct 5, 2018)

First release
