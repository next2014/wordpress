# CHANGELOG.md

## 1.0.1 (Dec 16, 2018)

##### Update PDF file
* /Blue.pdf

## 1.0.0 (Nov 28, 2018)

First release
