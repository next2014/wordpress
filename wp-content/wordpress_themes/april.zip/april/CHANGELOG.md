# CHANGELOG.md

## 1.0.3 (Dec 16, 2018)

##### Update PDF file
* /April.pdf

## 1.0.2 (Nov 19, 2018)

##### Update PDF file
* /April.pdf

## 1.0.1 (Nov 8, 2018)

##### Fix typo
* /index.html

## 1.0.0 (Oct 19, 2018)

First release
