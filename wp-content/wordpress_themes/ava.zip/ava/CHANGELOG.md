# CHANGELOG.md

## 1.1.3 (Dec 16, 2018)

##### Update PDF file
* /Ava.pdf

## 1.1.2 (Nov 19, 2018)

##### Update PDF file
* /Ava.pdf

## 1.1.1 (Nov 8, 2018)

##### Fix typo
* /index.html

## 1.1.0 (Oct 5, 2018)

##### Update license and PDF
* /Ava.pdf
* /package-sample.json
* /LICENSE

## 1.0.9 (Sep 25, 2018)

##### Fix minor typographic issue and small buttons fix
* /src/scss/base/_typography.scss
* /src/scss/components/_buttons.scss

## 1.0.8 (Sep 18, 2018)

##### Fix forms and buttons height issue on Safari
* /src/scss/components/_buttons.scss
* /src/scss/components/_forms.scss

## 1.0.7 (Sep 17, 2018)

##### Update template name
* /README.md

## 1.0.6 (Sep 15, 2018)

##### Minor CSS fix
* /src/scss/layout/_features.scss

## 1.0.5 (Sep 13, 2018)

##### Minor CSS fix
* /src/scss/base/_base.scss

## 1.0.4 (Sep 11, 2018)

##### Update license
* /package-sample.json
* /LICENSE.rtf

## 1.0.3 (Sep 11, 2018)

##### Keep animating elements visible when animations are disabled
* /src/scss/base/_helpers.scss

## 1.0.2 (Sep 10, 2018)

##### Fix buttons aspect conflict
* /src/scss/layout/_buttons.scss

## 1.0.1 (Sep 10, 2018)

##### Fixed typo
* /src/scss/layout/_footer.scss

## 1.0.0 (Aug 27, 2018)

First release
